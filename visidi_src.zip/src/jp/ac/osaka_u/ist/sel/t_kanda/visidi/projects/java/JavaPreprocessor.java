//Copyright (c) 2012 Tetsuya Kanda
//http://sel.ist.osaka-u.ac.jp/~t-kanda/
//
//Permission is hereby granted, free of charge, to any person obtaining
//a copy of this software and associated documentation files (the
//"Software"), to deal in the Software without restriction, including
//without limitation the rights to use, copy, modify, merge, publish,
//distribute, sublicense, and/or sell copies of the Software, and to
//permit persons to whom the Software is furnished to do so, subject to
//the following conditions:
//
//The above copyright notice and this permission notice shall be
//included in all copies or substantial portions of the Software.
//
//THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
//EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
//MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
//NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
//LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
//OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
//WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

package jp.ac.osaka_u.ist.sel.t_kanda.visidi.projects.java;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.List;

import jp.ac.osaka_u.ist.sel.t_kanda.visidi.DirecttoryUtil;
import jp.ac.osaka_u.ist.sel.t_kanda.visidi.EncodeDetector;
import jp.ac.osaka_u.ist.sel.t_kanda.visidi.projects.FileInfo;
import jp.ac.osaka_u.ist.sel.t_kanda.visidi.projects.Preprocessor;

import org.antlr.runtime.ANTLRFileStream;
import org.antlr.runtime.CommonTokenStream;
import org.antlr.runtime.Token;



/**
 * Java�t�@�C���p�O�����B
 * �ގ��x�v�Z�O�̓R�����g�����ƃg�[�N�������s���B
 * �����v�Z�O�͉������Ȃ�
 * @author t-kanda
 *
 */
public class JavaPreprocessor extends Preprocessor {
	
	public JavaPreprocessor(String tmp) {
		super(tmp);
	}

	private static final String SEPARATOR = File.separator;

	@Override
	public void preprocessForCalcSimilarity(FileInfo source) {
		String tmp = "tmp" + SEPARATOR + source.projectId() + SEPARATOR + source.parent().getName();
		DirecttoryUtil.initDirectory(tmp);
		File path = new File(tmp + SEPARATOR + source.fileId() + "_t.tmp");
		readIdentifiers(source.path(), path);
		source.preSim = path;
	}

	@SuppressWarnings("unchecked")
	public static int readIdentifiers(String inputJavaSourceFileName, File path) {
		ANTLRFileStream in;
		try {
			in = new ANTLRFileStream(inputJavaSourceFileName, EncodeDetector.detect(new File(inputJavaSourceFileName)));
			JavaLexer lexer = new JavaLexer(in);
			CommonTokenStream tokens = new CommonTokenStream(lexer);
			StringBuilder buffer = new StringBuilder();
			for (Token t : (List<Token>) tokens.getTokens()) {
				// �R�����g�Ƌ󔒂͏���
				if (t.getType() != JavaLexer.COMMENT && t.getType() != JavaLexer.WS && t.getType() != JavaLexer.LINE_COMMENT) {
					buffer.append(t.getText() + "\n");
				}
			}

			BufferedWriter bw = new BufferedWriter(new FileWriter(path));
			bw.write(buffer.toString());
			bw.close();

			return in.getLine();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return 0;
	}

	@Override
	public void preprocessForDiff(FileInfo source) {
		// TODO Auto-generated method stub

	}

}
