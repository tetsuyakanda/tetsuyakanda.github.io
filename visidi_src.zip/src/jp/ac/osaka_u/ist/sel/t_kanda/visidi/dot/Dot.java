package jp.ac.osaka_u.ist.sel.t_kanda.visidi.dot;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.util.Set;

import gnu.trove.iterator.TIntIterator;
import gnu.trove.map.TIntObjectMap;
import gnu.trove.set.TIntSet;
import jp.ac.osaka_u.ist.sel.t_kanda.visidi.projects.DirectoryInfo;
import jp.ac.osaka_u.ist.sel.t_kanda.visidi.projects.FileInfo;
import jp.ac.osaka_u.ist.sel.t_kanda.visidi.similarity.Edge;
import jp.ac.osaka_u.ist.sel.t_kanda.visidi.similarity.Group;
import jp.ac.osaka_u.ist.sel.t_kanda.visidi.similarity.Similarity;

/**
 * �^����ꂽ���_�̏W���ƕӂ̏W�������ƂɁA Dot�`���̃t�@�C���������o���܂��B
 * 
 * @author t-kanda
 * 
 */
public class Dot {

	private final static String[] COLORS = { "#FF9999", "#FFCC66", "#FFFF33", "#CCFF66", "#99FF99", "#66FFCC",
			"#33FFFF", "#66CCFF", "#9999FF", "#CC66FF", "#FF33FF" };

	public static File dot(int groupId, Group group, TIntObjectMap<FileInfo> files,
			TIntObjectMap<DirectoryInfo> projects, Similarity diffmap, TIntObjectMap<TIntSet> correspond) {
		File tmp = new File("dot\\" + groupId + ".dot");
		try {
			FileOutputStream fos = new FileOutputStream(tmp);
			OutputStreamWriter os = new OutputStreamWriter(fos);
			os.append(graph(groupId, group, files, projects, diffmap, correspond));
			os.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return tmp;
	}

	/**
	 * �����t�@�C�����ЂƂ܂Ƃ߂ɂ���Ă���Ƃ��p���x��������
	 * @param files
	 * @param correspond
	 * @param node
	 * @return
	 */
	private static String fileNameSet(TIntObjectMap<FileInfo> files, TIntObjectMap<TIntSet> correspond, int node) {
		StringBuilder buffer = new StringBuilder();
		for (TIntIterator it = correspond.get(node).iterator(); it.hasNext();) {
			int fid = it.next();
			buffer.append(files.get(fid).projectId() + ": " + files.get(fid).fileName() + "\\n");
		}
		return buffer.toString();
	}

	/**
	 * �O���t�̍쐬
	 * @param groupId
	 * @param group
	 * @param files
	 * @param projects
	 * @param diffmap
	 * @param correspond
	 * @return
	 */
	public static String graph(int groupId, Group group, TIntObjectMap<FileInfo> files,
			TIntObjectMap<DirectoryInfo> projects, Similarity diffmap, TIntObjectMap<TIntSet> correspond) {
		StringBuilder buffer = new StringBuilder();
		buffer.append("graph GROUP_" + groupId + "{ \n");
		buffer.append("overlap = scale;\n");
		/*
		 * ���_������
		 */
		for (TIntIterator i = group.files().iterator(); i.hasNext();) {
			int node = i.next();
			String color = (node < 0) ? "#FFFFFF" : COLORS[files.get(node).projectId() % COLORS.length];
			if (correspond != null && correspond.containsKey(node)) {
				buffer.append(String.format("%d [style=filled, shape = box, fillcolor = \"%s\", label=\"%s\"];\n",
						node, color, fileNameSet(files, correspond, node)));
			} else {
				buffer.append(String.format("%d [style=filled, shape = box, fillcolor = \"%s\", label=\"%s\"];\n",
						node, color, files.get(node).projectId() + ": " + files.get(node).fileName()));
			}
		}
		
		/*
		 * �ӂ��Ђ�
		 */
		for (Edge edge : group.edges()) {
			int node1 = edge.fileId1();
			int node2 = edge.fileId2();

			buffer.append(String.format("%d -- %d [label = \"%d\" penwidth=%.1f];\n", node1, node2,
					diffmap.getDiffSize(edge), (long) diffmap.getDiffSize(edge) * 0.01 + 0.3));

		}

		buffer.append("}");

		return buffer.toString();
	}

	public static File dot(int groupId, Group group, Set<DirectoryInfo> directories,
			TIntObjectMap<DirectoryInfo> projects, Similarity diffmap) {
		File tmp = new File("dot\\D" + groupId + ".dot");
		try {
			FileOutputStream fos = new FileOutputStream(tmp);
			OutputStreamWriter os = new OutputStreamWriter(fos);
			os.append(graph(groupId, group, directories, projects, diffmap));
			os.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return tmp;
	}

	public static String graph(int groupId, Group group, Set<DirectoryInfo> directories,
			TIntObjectMap<DirectoryInfo> projects, Similarity diffmap) {
		StringBuilder buffer = new StringBuilder();
		buffer.append("graph GROUP_D" + groupId + "{ \n");
		for (TIntIterator i = group.files().iterator(); i.hasNext();) {
			int node = i.next();
			for (DirectoryInfo di : directories) {
				if (di.fileId() == node) {
					String color = COLORS[di.projectId() % COLORS.length];
					buffer.append(String.format("%d [style=filled, shape = box, fillcolor = \"%s\", label=\"%s\"];\n",
							node, color, di.getPath()));
				}

			}
		}
		for (Edge edge : group.edges()) {
			int node1 = edge.fileId1();
			int node2 = edge.fileId2();
			buffer.append(String.format("%d -- %d [label = \"%.4f\" penwidth=%.1f];\n", node1, node2,
					diffmap.getSimilarity(edge), diffmap.getSimilarity(edge) * 20));
		}

		return buffer.toString();
	}
}
