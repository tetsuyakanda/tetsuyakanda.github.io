//Copyright (c) 2012 Tetsuya Kanda
//http://sel.ist.osaka-u.ac.jp/~t-kanda/
//
//Permission is hereby granted, free of charge, to any person obtaining
//a copy of this software and associated documentation files (the
//"Software"), to deal in the Software without restriction, including
//without limitation the rights to use, copy, modify, merge, publish,
//distribute, sublicense, and/or sell copies of the Software, and to
//permit persons to whom the Software is furnished to do so, subject to
//the following conditions:
//
//The above copyright notice and this permission notice shall be
//included in all copies or substantial portions of the Software.
//
//THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
//EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
//MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
//NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
//LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
//OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
//WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

package jp.ac.osaka_u.ist.sel.t_kanda.visidi.similarity;

import java.util.Iterator;
import java.util.Set;

import gnu.trove.iterator.TIntIterator;
import gnu.trove.map.TIntIntMap;
import gnu.trove.map.TIntObjectMap;
import gnu.trove.map.hash.TIntIntHashMap;
import gnu.trove.map.hash.TIntObjectHashMap;
import gnu.trove.set.TIntSet;
import gnu.trove.set.hash.THashSet;
import gnu.trove.set.hash.TIntHashSet;

/**
 * �ŏ��S��،v�Z�E�ێ��N���X
 * 
 * @author t-kanda
 * 
 */
public class SpanningTree {
	private Similarity diffmap;
	private Group[] spanningTree;
	private int[] root;
	private int correspondId = -1;
	private TIntObjectMap<TIntSet> correspondMap;

	public SpanningTree(Similarity diffmap, int size) {
		this.diffmap = diffmap;
		spanningTree = new Group[size];
		correspondMap = new TIntObjectHashMap<TIntSet>();
		root = new int[size];
	}

	public Group get(int index) {
		return spanningTree[index];
	}

	public int getRoot(int index) {
		return root[index];
	}

	/**
	 * diff�̍s�������Ƃɍŏ��S��؂����߂�
	 * 
	 * @param group
	 *            ���߂����O���[�v
	 * @return �ŏ��S��؁i���͂�group����ӂ����肵�����́j
	 */
	public Group getSpanningTree(int index, Group source) {

		Group group = correspondNodes(source);

		if (group.files().size() == 1) {
			spanningTree[index] = group;
			root[index] = findRoot(group);
			return group;
		}

		// �܂��ǉ����Ă��Ȃ����_�̏W��U
		TIntSet unknown = new TIntHashSet(group.files());
		// �n�߂͓K��
		int start = unknown.iterator().next();
		unknown.remove(start);
		int maxSize = group.files().size();

		// �ǉ��ς݂̒��_�̏W��V
		TIntSet vNew = new TIntHashSet((int) (maxSize * 1.25));
		vNew.add(start);

		Group sp = new Group();

		// ���ׂĂ̒��_��ǉ������炨���܂�
		while (vNew.size() != maxSize) {
			int newNode = -1;
			int minValue = Integer.MAX_VALUE;
			Edge minEdge = null;
			// v �� V�@����
			for (TIntIterator i = vNew.iterator(); i.hasNext();) {
				int v = i.next();
				// u �� U �����ԕӂ�T��
				for (TIntIterator j = unknown.iterator(); j.hasNext();) {
					int u = j.next();
					Edge edge = new Edge(v, u);
					int diffSize = diffmap.getDiffSize(edge);
					if (diffSize != -1 && diffSize < minValue) {
						minValue = diffSize;
						minEdge = edge;
						newNode = u;
					}
				}
			}
			// ���̂��������̍s�����ł��������̂��̂�ǉ�����
			sp.addEdge(minEdge);
			vNew.add(newNode);
			unknown.remove(newNode);
		}
		spanningTree[index] = sp;
		root[index] = findRoot(sp);
		return sp;
	}

	/**
	 * ����T��
	 * 
	 * @return
	 * 
	 * @return
	 */
	private int findRoot(Group sp) {
		if (sp.files().size() == 1) {
			return sp.files().iterator().next();
		}
		TIntSet files = new TIntHashSet(sp.files());
		// Map<Integer, Double> minDistance = null;
		int minTreeSize = Integer.MAX_VALUE;
		int root = -1;
		// r�����Ǝv���ĒT��
		for (TIntIterator i = files.iterator(); i.hasNext();) {
			int r = i.next();
			TIntIntMap dis = new TIntIntHashMap();
			TIntSet unknown = new TIntHashSet(sp.files());
			TIntSet seen = new TIntHashSet();
			unknown.remove(r);
			seen.add(r);
			dis.put(r, 0);
			int size = 0;
			while (dis.size() != files.size()) {
				TIntSet remember = new TIntHashSet();
				// ������̋��������m�̒��_����
				for (TIntIterator is = seen.iterator(); is.hasNext();) {
					int s = is.next();
					// ������̋��������m�̒��_�ւ̕ӂ�T��
					for (TIntIterator iu = unknown.iterator(); iu.hasNext();) {
						int u = iu.next();
						Edge edge = new Edge(s, u);
						int diff = diffmap.getDiffSize(edge);
						if (diff > 0) {
							// ������̋����́Ar~s + s~u
							dis.put(u, diff + dis.get(s));
							size += diff + dis.get(s);
							remember.add(u);
						}
					}
					unknown.removeAll(remember);
				}
				seen.addAll(remember);
			}

			// �ŏ���?
			if (size < minTreeSize) {
				minTreeSize = size;
				root = r;
			}
		}
		return root;
	}

	/**
	 * �������Ȃ����S�Ɉ�v�����t�@�C�����܂Ƃ߂�B
	 * �t�@�C��ID���̗̈�ɉ��f�[�^��u���B
	 * @param source
	 * @return
	 */
	private Group correspondNodes(Group source) {
		Group group = new Group();
		group.addAll(source);
		Set<TIntSet> sSet = new THashSet<TIntSet>();
		for (Iterator<Edge> it = group.edges().iterator(); it.hasNext();) {
			Edge edge = it.next();
			if (diffmap.getDiffSize(edge) == 0) {
				it.remove();
				Set<TIntSet> toBeDeleted = new THashSet<TIntSet>();
				TIntSet newSet = new TIntHashSet();
				for (TIntSet same : sSet) {
					if (same.contains(edge.fileId1()) || same.contains(edge.fileId2())) {
						toBeDeleted.add(same);
						newSet.addAll(same);
					}
				}
				newSet.add(edge.fileId1());
				newSet.add(edge.fileId2());
				sSet.removeAll(toBeDeleted);
				sSet.add(newSet);
			}
		}

		TIntIntMap correspond = new TIntIntHashMap();

		for (TIntSet same : sSet) {
			group.removeFiles(same);
			group.addFile(correspondId);
			for (TIntIterator i = same.iterator(); i.hasNext();) {
				int fid = i.next();
				correspond.put(fid, correspondId);
			}
			correspondMap.put(correspondId, same);
			correspondId--;
		}

		Set<Edge> newEdges = new THashSet<Edge>();
		for (Iterator<Edge> it = group.edges().iterator(); it.hasNext();) {
			Edge edge = it.next();
			if (correspond.containsKey(edge.fileId1()) && !correspond.containsKey(edge.fileId2())) {
				Edge newEdge = new Edge(correspond.get(edge.fileId1()), edge.fileId2());
				diffmap.setDiffString(newEdge, diffmap.getDiffString(edge));
				it.remove();
				newEdges.add(newEdge);
			} else if (!correspond.containsKey(edge.fileId1()) && correspond.containsKey(edge.fileId2())) {
				Edge newEdge = new Edge(correspond.get(edge.fileId2()), edge.fileId1());
				diffmap.setDiffString(newEdge, diffmap.getDiffString(edge));
				it.remove();
				newEdges.add(newEdge);
			} else if (correspond.containsKey(edge.fileId1()) && correspond.containsKey(edge.fileId2())) {
				Edge newEdge = new Edge(correspond.get(edge.fileId2()), correspond.get(edge.fileId1()));
				diffmap.setDiffString(newEdge, diffmap.getDiffString(edge));
				it.remove();
				newEdges.add(newEdge);
			}
		}
		for (Edge edge : newEdges) {
			group.addEdge(edge);
		}

		return group;
	}

	public TIntObjectMap<TIntSet> correspond() {
		return correspondMap;
	}

	/**
	 * �ގ��x�Ɋ�Â��ŏ��S��؂����߂�
	 * 
	 * @param group
	 *            ���߂����O���[�v
	 * @return �ŏ��S��؁i���͂�group����ӂ����肵�����́j
	 */
	public Group getDirectorySpanningTree(Group group) {
		if (group.files().size() == 1) {
			return group;
		}
		// �܂��ǉ����Ă��Ȃ����_�̏W��U
		TIntSet unknown = new TIntHashSet(group.files());
		// �n�߂͓K��
		int start = unknown.iterator().next();
		unknown.remove(start);
		int maxSize = group.files().size();

		// �ǉ��ς݂̒��_�̏W��V
		TIntSet vNew = new TIntHashSet((int) (maxSize * 1.25));
		vNew.add(start);

		Group sp = new Group();

		// ���ׂĂ̒��_��ǉ������炨���܂�
		while (vNew.size() != maxSize) {
			int newNode = -1;
			double minValue = Double.MAX_VALUE;
			Edge minEdge = null;
			// v �� V�@����
			for (TIntIterator i = vNew.iterator(); i.hasNext();) {
				int v = i.next();
				// u �� U �����ԕӂ�T��
				for (TIntIterator j = unknown.iterator(); j.hasNext();) {
					int u = j.next();
					Edge edge = new Edge(v, u);
					double distance = (1.0 - diffmap.getSimilarity(edge));
					if (distance < 1.0 && distance < minValue) {
						minValue = distance;
						minEdge = edge;
						newNode = u;
					}
				}
			}
			// ���̂����ގ��x���ł��傫���̂��̂�ǉ�����
			sp.addEdge(minEdge);
			vNew.add(newNode);
			unknown.remove(newNode);
		}
		System.out.println(group.edges());
		System.out.println(sp.edges());
		return sp;
	}
}
