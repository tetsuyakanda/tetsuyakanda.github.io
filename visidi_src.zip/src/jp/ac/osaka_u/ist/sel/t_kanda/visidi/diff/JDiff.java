//Copyright (c) 2012 Tetsuya Kanda
//http://sel.ist.osaka-u.ac.jp/~t-kanda/
//
//Permission is hereby granted, free of charge, to any person obtaining
//a copy of this software and associated documentation files (the
//"Software"), to deal in the Software without restriction, including
//without limitation the rights to use, copy, modify, merge, publish,
//distribute, sublicense, and/or sell copies of the Software, and to
//permit persons to whom the Software is furnished to do so, subject to
//the following conditions:
//
//The above copyright notice and this permission notice shall be
//included in all copies or substantial portions of the Software.
//
//THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
//EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
//MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
//NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
//LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
//OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
//WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

package jp.ac.osaka_u.ist.sel.t_kanda.visidi.diff;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.incava.util.diff.Diff;
import org.incava.util.diff.Difference;

//Similarity(A, B) = |A∩B| / |A∪B|

/**
 * Java-diffを用いて類似度計算を行う
 * 
 * @author t-kanda
 * 
 */
public class JDiff implements DiffInterface {

	public final static int DIFF_LINE = 0;
	public final static int DIFF_TOKEN = 1;

	/**
	 * Similarity(A, B) = |A∩B| / |A∪B|<br>
	 * 計算の際空白空行を無視する
	 * 
	 * @param file1
	 *            ソース??
	 * @param file2
	 *            ソース2
	 * @return 類似度
	 */
	public float similarity(File file1, File file2) {

		List<String> sA = new ArrayList<String>();
		List<String> sB = new ArrayList<String>();
		try {
			String line;
			BufferedReader fin1 = new BufferedReader(new FileReader(file1));
			while (null != (line = fin1.readLine())) {
				line = line.replaceAll("[ \t]", "");
				if (line.length() > 0) {
					sA.add(line);
				}
			}
			fin1.close();
			BufferedReader fin2 = new BufferedReader(new FileReader(file2));
			while (null != (line = fin2.readLine())) {
				line = line.replaceAll("[ \t]", "");
				if (line.length() > 0) {
					sB.add(line);
				}
			}
			fin2.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		Diff<String> diff = new Diff<String>(sA, sB);
		List<Difference> diffList = diff.diff();
		int nDiffAB = 0;
		for (Difference d : diffList) {
			if (d.getDeletedEnd() >= 0) {
				nDiffAB += d.getDeletedEnd() - d.getDeletedStart() + 1;
			}
			if (d.getAddedEnd() >= 0) {
				nDiffAB += d.getAddedEnd() - d.getAddedStart() + 1;
			}
		}

		int nUnionAB2 = sA.size() + sB.size() + nDiffAB;
		int nIntersectionAB2 = sA.size() + sB.size() - nDiffAB;

		return (float) nIntersectionAB2 / nUnionAB2;
	}

	/**
	 * diffの出力を返す
	 * 
	 * @param file1
	 * @param file2
	 * @return 2ファイルのdiff
	 */
	public String diff(File file1, File file2) {
		List<String> sA = new ArrayList<String>();
		List<String> sB = new ArrayList<String>();
		BufferedReader fin;
		try {
			String line;
			fin = new BufferedReader(new FileReader(file1));
			while (null != (line = fin.readLine())) {
				sA.add(line);
			}
			fin.close();
			fin = new BufferedReader(new FileReader(file2));
			while (null != (line = fin.readLine())) {
				sB.add(line);
			}
			fin.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		List<Difference> diffList = new Diff<String>(sA, sB).diff();
		if (diffList.size() > 0) {
			StringBuilder buf = new StringBuilder();
			buf.append(String.format("--- %9s   %s\n", file1.getAbsolutePath(),
					new Date(file1.lastModified()).toString()));
			buf.append(String.format("+++ %9s   %s\n", file1.getAbsolutePath(),
					new Date(file1.lastModified()).toString()));
			for (Difference d : diffList) {
				if (d.getDeletedEnd() >= 0) {
					if (d.getAddedEnd() >= 0) {
						if (d.getDeletedEnd() == d.getDeletedStart()) {
							buf.append(d.getDeletedStart() + 1);
						} else {
							buf.append((d.getDeletedStart() + 1) + "," + (d.getDeletedEnd() + 1));
						}
						buf.append('c');
						if (d.getAddedEnd() == d.getAddedStart()) {
							buf.append(d.getAddedStart() + 1);
						} else {
							buf.append((d.getAddedStart() + 1) + "," + (d.getAddedEnd() + 1));
						}
						buf.append('\n');
						for (int i = d.getDeletedStart(); i <= d.getDeletedEnd(); i++) {
							buf.append("< " + sA.get(i));
							buf.append('\n');
						}
						buf.append("---\n");
						for (int i = d.getAddedStart(); i <= d.getAddedEnd(); i++) {
							buf.append("> " + sB.get(i));
							buf.append('\n');
						}
					} else {
						if (d.getDeletedEnd() == d.getDeletedStart()) {
							buf.append(d.getDeletedStart() + 1);
						} else {
							buf.append((d.getDeletedStart() + 1) + "," + (d.getDeletedEnd() + 1));
						}
						buf.append('d');
						buf.append(d.getAddedStart());
						buf.append('\n');
						for (int i = d.getDeletedStart(); i <= d.getDeletedEnd(); i++) {
							buf.append("< " + sA.get(i));
							buf.append('\n');
						}
					}
				} else if (d.getAddedEnd() >= 0) {
					buf.append(d.getDeletedStart());
					buf.append('a');
					if (d.getAddedEnd() == d.getAddedStart()) {
						buf.append(d.getAddedStart() + 1);
					} else {
						buf.append((d.getAddedStart() + 1) + "," + (d.getAddedEnd() + 1));
					}
					buf.append('\n');
					for (int i = d.getAddedStart(); i <= d.getAddedEnd(); i++) {
						buf.append("> " + sB.get(i));
						buf.append('\n');
					}
				}
			}
			return buf.toString();
		} else {
			return "";
		}
	}
}
