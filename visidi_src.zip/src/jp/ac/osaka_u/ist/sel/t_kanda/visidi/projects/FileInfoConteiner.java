//Copyright (c) 2012 Tetsuya Kanda
//http://sel.ist.osaka-u.ac.jp/~t-kanda/
//
//Permission is hereby granted, free of charge, to any person obtaining
//a copy of this software and associated documentation files (the
//"Software"), to deal in the Software without restriction, including
//without limitation the rights to use, copy, modify, merge, publish,
//distribute, sublicense, and/or sell copies of the Software, and to
//permit persons to whom the Software is furnished to do so, subject to
//the following conditions:
//
//The above copyright notice and this permission notice shall be
//included in all copies or substantial portions of the Software.
//
//THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
//EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
//MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
//NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
//LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
//OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
//WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

package jp.ac.osaka_u.ist.sel.t_kanda.visidi.projects;

import gnu.trove.map.TIntObjectMap;
import gnu.trove.map.TObjectCharMap;
import gnu.trove.map.hash.TIntObjectHashMap;

import java.io.File;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import jp.ac.osaka_u.ist.sel.t_kanda.visidi.DirecttoryUtil;
import jp.ac.osaka_u.ist.sel.t_kanda.visidi.OptionContainer;
import jp.ac.osaka_u.ist.sel.t_kanda.visidi.ParaRun;

/**
 * �t�@�C���Ǎ��A���ێ��N���X
 * 
 * @author t-kanda
 * 
 */
public class FileInfoConteiner implements Serializable {

	private static final long serialVersionUID = 3037556265781290701L;
	private int nextFileId = 0;
	private int nextProjectId = 0;
	private int totalLOC = 0;
	private TObjectCharMap<String> types;
	private TIntObjectMap<FileInfo> files, newfiles;
	private TIntObjectMap<DirectoryInfo> projects;
	private String tmp;

	/*
	 * private static final ObjectStreamField[] serialPersistentFields = { new
	 * ObjectStreamField("files", TIntObjectMap.class) };
	 */

	public FileInfoConteiner(OptionContainer options) {
		this.types = options.types();
		files = new TIntObjectHashMap<FileInfo>();
		projects = new TIntObjectHashMap<DirectoryInfo>();
		this.tmp = options.tmp();
	}

	public void SetType(OptionContainer options) {
		this.types = options.types();
	}

	public Collection<FileInfo> readProject(File f) {
		DirecttoryUtil.initDirectory(tmp + '\\' + nextProjectId);
		ParaRun<Reader> pararun = new ParaRun<Reader>();
		List<Reader> reads = new ArrayList<Reader>();
		DirectoryInfo d = readFile(f, reads, nextProjectId, null);
		pararun.addAll(reads);
		newfiles = new TIntObjectHashMap<FileInfo>();
		pararun.run();
		files.putAll(newfiles);
		projects.put(nextProjectId, d);
		nextProjectId++;
		return newfiles.valueCollection();
	}

	private DirectoryInfo readFile(File f, List<Reader> reads, int projectId, DirectoryInfo parent) {
		if (f.isDirectory()) {
			DirectoryInfo d = new DirectoryInfo(f, nextFileId++, projectId, parent);
			for (File file : f.listFiles()) {
				DirectoryInfo child = readFile(file, reads, projectId, d);
				if (child != null) {
					d.addDirectory(child);
				}
			}
			return d;
		} else if (f.isFile()) {
			String type = f.getName().toLowerCase().substring(f.getName().lastIndexOf('.') + 1);
			if (types.containsKey(type)) {
				reads.add(new Reader(f, nextFileId++, projectId, parent, types.get(type)));
			}
		}
		return null;
	}

	private synchronized void addTotalLoc(int loc) {
		totalLOC += loc;
	}

	private class Reader implements Runnable {

		File f;
		int fileId;
		int projectId;
		DirectoryInfo parent;
		char type;

		public Reader(File f, int fileId, int projectId, DirectoryInfo parent, char type) {
			this.f = f;
			this.fileId = fileId;
			this.projectId = projectId;
			this.parent = parent;
			this.type = type;
		}

		@Override
		public void run() {

			FileInfo fi = new FileInfo(fileId, projectId, f, parent, type);
			Preprocessor pp = PreprocessorFactory.create(type, tmp);
			pp.preprocessForCalcSimilarity(fi);
			pp.preprocessForDiff(fi);
			synchronized (newfiles) {
				newfiles.put(fileId, fi);
			}
			addTotalLoc(fi.line());

		}
	}

	public TIntObjectMap<FileInfo> files() {
		return files;
	}

	public int loc() {
		return totalLOC;
	}

	public TIntObjectMap<DirectoryInfo> projects() {
		return projects;
	}
}
