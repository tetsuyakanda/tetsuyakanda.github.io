//Copyright (c) 2012 Tetsuya Kanda
//http://sel.ist.osaka-u.ac.jp/~t-kanda/
//
//Permission is hereby granted, free of charge, to any person obtaining
//a copy of this software and associated documentation files (the
//"Software"), to deal in the Software without restriction, including
//without limitation the rights to use, copy, modify, merge, publish,
//distribute, sublicense, and/or sell copies of the Software, and to
//permit persons to whom the Software is furnished to do so, subject to
//the following conditions:
//
//The above copyright notice and this permission notice shall be
//included in all copies or substantial portions of the Software.
//
//THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
//EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
//MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
//NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
//LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
//OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
//WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

package jp.ac.osaka_u.ist.sel.t_kanda.visidi.projects;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.LineNumberReader;
import java.io.Serializable;

/**
 * 
 * �t�@�C�����Ƃ̏����i�[����N���X�B ID�ƃ\�[�X�ւ̃p�X�A�g�[�N���������t�@�C���ւ̃|�C���^���i�[�B
 * 
 * @author t-kanda
 * 
 */
public class FileInfo implements Serializable{

	private static final long serialVersionUID = -9219947371289528865L;

	private int fileId;
	private int projectId;
	private File file;
	private int line;
	private char type;
	private DirectoryInfo parent;
	public File preSim, preDiff;

	/**
	 * �t�@�C�����𐶐��BID�ƃp�X�������Ă�������
	 * 
	 * @param fileId
	 * @param projectId
	 * @param path
	 */
	public FileInfo(int fileId, int projectId, File f, DirectoryInfo parent, char type) {
		this.fileId = fileId;
		this.projectId = projectId;
		this.file = f;
		this.type = type;
		this.line = wc();
		this.parent = parent;
		if(parent != null){
			parent.addFile(fileId);
		}
		preSim = file;
		preDiff = file;
	}

	private int wc() {
		LineNumberReader fin;
		try {
			fin = new LineNumberReader(new FileReader(file));

			while (null !=fin.readLine()) {
				;
			}
			int wc = fin.getLineNumber();
			fin.close();
			return wc;
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return 0;
	}

	/**
	 * @return�@FileID
	 */
	public int fileId() {
		return fileId;
	}

	/**
	 * @return �\�[�X�t�@�C���̃p�X
	 */
	public String path() {
		return file.getAbsolutePath();
	}

	public File file() {
		return file;
	}

	public int projectId() {
		return projectId;
	}

	public String toString() {
		return "" + fileId;
	}

	public String fileName() {
		return path().substring(path().lastIndexOf(File.separator) + 1);
	}

	public int line() {
		return line;
	}

	public char type() {
		return type;
	}
	
	public DirectoryInfo parent(){
		return parent;
	}
}
