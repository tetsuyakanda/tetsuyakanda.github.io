//Copyright (c) 2012 Tetsuya Kanda
//http://sel.ist.osaka-u.ac.jp/~t-kanda/
//
//Permission is hereby granted, free of charge, to any person obtaining
//a copy of this software and associated documentation files (the
//"Software"), to deal in the Software without restriction, including
//without limitation the rights to use, copy, modify, merge, publish,
//distribute, sublicense, and/or sell copies of the Software, and to
//permit persons to whom the Software is furnished to do so, subject to
//the following conditions:
//
//The above copyright notice and this permission notice shall be
//included in all copies or substantial portions of the Software.
//
//THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
//EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
//MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
//NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
//LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
//OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
//WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

package jp.ac.osaka_u.ist.sel.t_kanda.visidi.similarity;

import java.io.Serializable;

/**
 * �t�@�C��2�����Ԗ����ӂ�\���N���X
 * @author t-kanda
 *
 */
public class Edge implements Serializable{

	private static final long serialVersionUID = -4126285877855723292L;
	private int fileId1;
	private int fileId2;
	
	/**
	 * 2�̃t�@�C�������Ԗ����ӂ����Bid�̑召�͋C�ɂ��Ȃ��ėǂ��B
	 * @param fileIdA
	 * @param fileIdB
	 */
	public Edge(int fileIdA, int fileIdB){
			fileId1 = fileIdA;
			fileId2 = fileIdB;
	}
	
	/**
	 * �t�@�C��ID�̂����A����������Ԃ�
	 * @return �t�@�C��ID�i���j
	 */
	public int fileId1(){
		return Math.min(fileId1,fileId2);
	}
	
	/**
	 * �t�@�C��ID�̂����A�傫������Ԃ�
	 * @return �t�@�C��ID�i��j
	 */
	public int fileId2(){
		return Math.max(fileId1,fileId2);
	}
	
	@Override
	public boolean equals(Object obj) {
		if (obj == null) {
			return false;
		}
		if (!(obj instanceof Edge)) {
			return false;
		}
		Edge target = (Edge) obj;
		return this.fileId1 == target.fileId1 && this.fileId2 == target.fileId2 || this.fileId1 == target.fileId2 && this.fileId2 == target.fileId1;
	}
	
	@Override
	public int hashCode() {
		return fileId1 + fileId2;
	}
	
	@Override
	public String toString() {
		return fileId1 + "-" + fileId2; 
	}

	public boolean contains(int fileId) {
		return fileId == fileId1 || fileId == fileId2;
	}
}
