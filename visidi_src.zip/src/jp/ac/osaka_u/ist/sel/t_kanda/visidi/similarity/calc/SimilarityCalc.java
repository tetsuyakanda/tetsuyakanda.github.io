//Copyright (c) 2012 Tetsuya Kanda
//http://sel.ist.osaka-u.ac.jp/~t-kanda/
//
//Permission is hereby granted, free of charge, to any person obtaining
//a copy of this software and associated documentation files (the
//"Software"), to deal in the Software without restriction, including
//without limitation the rights to use, copy, modify, merge, publish,
//distribute, sublicense, and/or sell copies of the Software, and to
//permit persons to whom the Software is furnished to do so, subject to
//the following conditions:
//
//The above copyright notice and this permission notice shall be
//included in all copies or substantial portions of the Software.
//
//THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
//EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
//MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
//NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
//LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
//OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
//WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

package jp.ac.osaka_u.ist.sel.t_kanda.visidi.similarity.calc;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.List;

import org.incava.util.diff.Diff;
import org.incava.util.diff.Difference;

import jp.ac.osaka_u.ist.sel.t_kanda.visidi.OptionContainer;
import jp.ac.osaka_u.ist.sel.t_kanda.visidi.ParaRun;
import jp.ac.osaka_u.ist.sel.t_kanda.visidi.diff.DiffFactory;
import jp.ac.osaka_u.ist.sel.t_kanda.visidi.diff.DiffInterface;
import jp.ac.osaka_u.ist.sel.t_kanda.visidi.projects.FileInfo;
import jp.ac.osaka_u.ist.sel.t_kanda.visidi.similarity.Edge;
import jp.ac.osaka_u.ist.sel.t_kanda.visidi.similarity.Similarity;
import jp.ac.osaka_u.ist.sel.t_kanda.visidi.similarity.SimilarityOnMemory;

/**
 * �t�@�C���ԗގ��x�v�Z���s�����߂̃N���X�B
 * 
 * @author t-kanda
 * 
 */
public class SimilarityCalc {
	private Similarity diffmap;
	private Collection<FileInfo> files;
	private DiffInterface diff;
	private Collection<FileInfo> addedFiles;
	private Creator calcMaker;

	private static final int PSIZE = 100000;
	private static final float SIMBORDER = 0.5f;

	/**
	 * new���Ďg���āB
	 * 
	 * @param diffmap
	 *            Similarity class
	 * @param files
	 *            collection of FileInfo
	 */
	public SimilarityCalc(Similarity diffmap, Collection<FileInfo> addedFiles, Collection<FileInfo> files,
			OptionContainer options) {
		this.diffmap = diffmap;
		this.files = files;
		this.addedFiles = addedFiles;
		diff = DiffFactory.create(options.diffCmd());
		calcMaker = options.onepath() ? new OnePathCreator() : new CalcCreator();
	}

	/**
	 * �v�Z�����s���܂��B
	 * 
	 * @return Similarity
	 */
	public Similarity calcSim() {
		ParaRun<Calc> pararun = new ParaRun<Calc>();
		for (FileInfo fii : addedFiles) {
			for (FileInfo fij : files) {
				// �d���h�~
				if (fii.fileId() > fij.fileId() && fii.type() == fij.type()) {
					// ��������
					// sim != NewSimilarity.DONTTOUCH or ��������̒l
					Edge edge = new Edge(fii.fileId(), fij.fileId());
					if (diffmap.getSimilarity(edge) == SimilarityOnMemory.NOVALUE) {
						pararun.add(calcMaker.create(edge, fii, fij));
					}
				}
			}
			if (pararun.size() > PSIZE) {
				System.out.println("ID " + fii.fileId());
				pararun.run();
				pararun.clear();
			}
		}

		pararun.run();
		return diffmap;
	}

	private interface Creator {
		Calc create(Edge edge, FileInfo fii, FileInfo fij);
	}

	private class CalcCreator implements Creator {
		@Override
		public Calc create(Edge edge, FileInfo fii, FileInfo fij) {
			return new Calc(edge, fii, fij);
		}
	}

	private class OnePathCreator implements Creator {
		@Override
		public Calc create(Edge edge, FileInfo fii, FileInfo fij) {
			return new OnePath(edge, fii, fij);
		}
	}

	/**
	 * �t�@�C���T�C�Y�����܂�ɂ��Ⴄ���̂�reject
	 */
	private boolean overSize(File file1, File file2) {
		return file1.length() < file2.length() * SIMBORDER || file1.length() * SIMBORDER > file2.length();
	}

	private class Calc implements Runnable {
		FileInfo fii, fij;
		Edge edge;

		private Calc(Edge edge, FileInfo fii, FileInfo fij) {
			this.fii = fii;
			this.fij = fij;
			this.edge = edge;
		}

		public void run() {
			// ����
			if (!overSize(fii.file(), fij.file())) {
				float similarity = diff.similarity(fii.preSim, fij.preSim);
				synchronized (diffmap) {
					diffmap.setSimilarity(edge, similarity);
				}
			}
		}
	}

	/**
	 * java-diff��p���A�ގ��x�v�Z�ƍ����擾�𓯎��ɍs���B
	 * �t�@�C���́A�����v�Z�p�ɑO�����������̂�p����B
	 * @author t-kanda
	 *
	 */
	private class OnePath extends Calc implements Runnable {

		private OnePath(Edge edge, FileInfo fii, FileInfo fij) {
			super(edge, fii, fij);
		}

		public void run() {
			File file1 = fii.preDiff;
			File file2 = fij.preDiff;
			// ����
			if (!overSize(file1, file2)) {
				List<String> sA = new ArrayList<String>();
				List<String> sB = new ArrayList<String>();
				try {
					String line;
					BufferedReader fin1 = new BufferedReader(new FileReader(file1));
					while (null != (line = fin1.readLine())) {
						line = line.replaceAll("[ \t]", "");
						if (line.length() > 0) {
							sA.add(line);
						}
					}
					fin1.close();
					BufferedReader fin2 = new BufferedReader(new FileReader(file2));
					while (null != (line = fin2.readLine())) {
						line = line.replaceAll("[ \t]", "");
						if (line.length() > 0) {
							sB.add(line);
						}
					}
					fin2.close();
				} catch (FileNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

				Diff<String> diff = new Diff<String>(sA, sB);
				List<Difference> diffList = diff.diff();
				int nDiffAB = 0;
				for (Difference d : diffList) {
					if (d.getDeletedEnd() >= 0) {
						nDiffAB += d.getDeletedEnd() - d.getDeletedStart() + 1;
					}
					if (d.getAddedEnd() >= 0) {
						nDiffAB += d.getAddedEnd() - d.getAddedStart() + 1;
					}
				}

				int nUnionAB2 = sA.size() + sB.size() + nDiffAB;
				int nIntersectionAB2 = sA.size() + sB.size() - nDiffAB;
				float sim = (float) nIntersectionAB2 / nUnionAB2;
				if (sim > SIMBORDER) {
					diffmap.setSimilarity(edge, sim);

					StringBuilder buf = new StringBuilder();
					buf.append(String.format("--- %9s   %s\n", file1.getAbsolutePath(),
							new Date(file1.lastModified()).toString()));
					buf.append(String.format("+++ %9s   %s\n", file1.getAbsolutePath(),
							new Date(file1.lastModified()).toString()));
					for (Difference d : diffList) {
						if (d.getDeletedEnd() >= 0) {
							if (d.getAddedEnd() >= 0) {
								if (d.getDeletedEnd() == d.getDeletedStart()) {
									buf.append(d.getDeletedStart() + 1);
								} else {
									buf.append((d.getDeletedStart() + 1) + "," + (d.getDeletedEnd() + 1));
								}
								buf.append('c');
								if (d.getAddedEnd() == d.getAddedStart()) {
									buf.append(d.getAddedStart() + 1);
								} else {
									buf.append((d.getAddedStart() + 1) + "," + (d.getAddedEnd() + 1));
								}
								buf.append('\n');
								for (int i = d.getDeletedStart(); i <= d.getDeletedEnd(); i++) {
									buf.append("< " + sA.get(i));
									buf.append('\n');
								}
								buf.append("---\n");
								for (int i = d.getAddedStart(); i <= d.getAddedEnd(); i++) {
									buf.append("> " + sB.get(i));
									buf.append('\n');
								}
							} else {
								if (d.getDeletedEnd() == d.getDeletedStart()) {
									buf.append(d.getDeletedStart() + 1);
								} else {
									buf.append((d.getDeletedStart() + 1) + "," + (d.getDeletedEnd() + 1));
								}
								buf.append('d');
								buf.append(d.getAddedStart());
								buf.append('\n');
								for (int i = d.getDeletedStart(); i <= d.getDeletedEnd(); i++) {
									buf.append("< " + sA.get(i));
									buf.append('\n');
								}
							}
						} else if (d.getAddedEnd() >= 0) {
							buf.append(d.getDeletedStart());
							buf.append('a');
							if (d.getAddedEnd() == d.getAddedStart()) {
								buf.append(d.getAddedStart() + 1);
							} else {
								buf.append((d.getAddedStart() + 1) + "," + (d.getAddedEnd() + 1));
							}
							buf.append('\n');
							for (int i = d.getAddedStart(); i <= d.getAddedEnd(); i++) {
								buf.append("> " + sB.get(i));
								buf.append('\n');
							}
						}
					}
					diffmap.setDiffString(edge, buf.toString());
				}
			}
		}

		public String toString() {
			return (fii.fileName() + " - " + fij.fileName());
		}

	}
}
