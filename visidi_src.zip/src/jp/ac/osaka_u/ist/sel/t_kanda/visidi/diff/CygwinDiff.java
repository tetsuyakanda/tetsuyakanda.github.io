//Copyright (c) 2012 Tetsuya Kanda
//http://sel.ist.osaka-u.ac.jp/~t-kanda/
//
//Permission is hereby granted, free of charge, to any person obtaining
//a copy of this software and associated documentation files (the
//"Software"), to deal in the Software without restriction, including
//without limitation the rights to use, copy, modify, merge, publish,
//distribute, sublicense, and/or sell copies of the Software, and to
//permit persons to whom the Software is furnished to do so, subject to
//the following conditions:
//
//The above copyright notice and this permission notice shall be
//included in all copies or substantial portions of the Software.
//
//THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
//EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
//MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
//NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
//LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
//OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
//WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

package jp.ac.osaka_u.ist.sel.t_kanda.visidi.diff;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

//Similarity(A, B) = |A��B| / |A��B|

/**
 * Cygwin�t����GNU diff��p���ėގ��x�v�Z���s��
 * 
 * @author t-kanda
 * 
 */
public class CygwinDiff implements DiffInterface {

	public final static int DIFF_LINE = 0;
	public final static int DIFF_TOKEN = 1;

	private final static char OLD_LINE = '-';
	private final static char NEW_LINE = '+';
	private final static char UNCHANGED_LINE = '*';

	/**
	 * diff�̃I�v�V�����B�󔒖����A��s�����A��A����������
	 */
	private final static String OPTION_BASE = "-iwB";

	/**
	 * diff�̃I�v�V�����Bunified�`���ŏo��
	 */
	// private final static String[] OPTIONS1 = { "-du" };
	private final static String[] OPTIONS1 = { OPTION_BASE, "-u" };

	/**
	 * diff�̃I�v�V�����B�s�̕ύX�̗L���𕶎��ɂ���
	 */
	private final static String[] OPTIONS2 = { OPTION_BASE, "--old-line-format=\"" + OLD_LINE + "\"", "--new-line-format=\"" + NEW_LINE + "\"",
			"--unchanged-line-format=\"" + UNCHANGED_LINE + "\"" };
	private String diffCommand;

	public CygwinDiff(String command) {
		diffCommand = command;
	}

	private static String cygPath(String path) {
		return path.replaceAll("\\\\", "/").replace("C:", "/cygdrive/c");
	}

	/**
	 * Similarity(A, B) = |A��B| / |A��B|
	 * 
	 * @param file1
	 *            �\�[�X1
	 * @param file2
	 *            �\�[�X2
	 * @return �ގ��x
	 */
	public float similarity(File file1, File file2) {
		String diff = execDiff(file1, file2, DIFF_TOKEN);
		int nUnionAB = diff.length() - 1; // \n����
		int nIntersectionAB = 0;
		for (char c : diff.toCharArray()) {
			if (c == UNCHANGED_LINE) {
				nIntersectionAB++;
			}
			/*
			 * switch (c) { case UNCHANGED_LINE: nIntersectionAB++; case
			 * OLD_LINE: case NEW_LINE: nUnionAB++; break; }
			 */
		}
		return (float) nIntersectionAB / nUnionAB;
	}

	public String diff(final File file1, final File file2) {
		return execDiff(file1, file2, DIFF_LINE);
	}

	private String execDiff(final File file1, final File file2, int option) {
		final StringBuilder buffer = new StringBuilder();
		Process p = null;
		try {
			List<String> command = new ArrayList<String>();
			command.add(diffCommand);
			// command.addAll(Arrays.asList(OPTIONS_BASE));
			switch (option) {
			case DIFF_TOKEN:
				command.addAll(Arrays.asList(OPTIONS2));
				break;
			case DIFF_LINE:
				command.addAll(Arrays.asList(OPTIONS1));
				break;
			default:
			}
			command.add(cygPath(file1.getAbsolutePath()));
			command.add(cygPath(file2.getAbsolutePath()));

			ProcessBuilder pb = new ProcessBuilder(command);
			p = pb.start();

			final InputStream is = p.getInputStream();
			final InputStream eis = p.getErrorStream();

			Thread outth = new Thread(new Runnable() {
				public void run() {
					BufferedReader br = new BufferedReader(new InputStreamReader(is));
					String result;
					try {
						while ((result = br.readLine()) != null) {
							buffer.append(result + "\n");
						}
						br.close();
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
			});

			Thread errth = new Thread(new Runnable() {
				public void run() {
					BufferedReader br = new BufferedReader(new InputStreamReader(eis));
					String result;
					try {
						while ((result = br.readLine()) != null) {
							System.err.println(result);
							System.err.println(file1 + " - " + file2);
						}

						br.close();
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
			});

			outth.start();
			errth.start();
			p.waitFor();
			outth.join();
			errth.join();
			is.close();
			eis.close();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.err.println("WHY");
			p.destroy();

		} finally {

		}
		return buffer.toString();
	}
}
