//Copyright (c) 2012 Tetsuya Kanda
//http://sel.ist.osaka-u.ac.jp/~t-kanda/
//
//Permission is hereby granted, free of charge, to any person obtaining
//a copy of this software and associated documentation files (the
//"Software"), to deal in the Software without restriction, including
//without limitation the rights to use, copy, modify, merge, publish,
//distribute, sublicense, and/or sell copies of the Software, and to
//permit persons to whom the Software is furnished to do so, subject to
//the following conditions:
//
//The above copyright notice and this permission notice shall be
//included in all copies or substantial portions of the Software.
//
//THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
//EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
//MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
//NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
//LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
//OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
//WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

package jp.ac.osaka_u.ist.sel.t_kanda.visidi.similarity;

import gnu.trove.iterator.TIntIterator;
import gnu.trove.map.TIntIntMap;
import gnu.trove.map.TIntObjectMap;
import gnu.trove.map.hash.TIntIntHashMap;
import gnu.trove.map.hash.TIntObjectHashMap;
import gnu.trove.set.TIntSet;
import gnu.trove.set.hash.THashSet;
import gnu.trove.set.hash.TIntHashSet;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Set;

import jp.ac.osaka_u.ist.sel.t_kanda.visidi.DirecttoryUtil;

/**
 * �t�@�C���Ԃ̊֌W��ێ�����N���X�B�ގ��x�Adiff�̏o�́Adiff�̏o�͂̍s�� �����f�[�^�͈ꎞ�t�H���_�ɏ����o���A���������ǂݍ���
 * �s�������̓I���������[
 * 
 * @author t-kanda
 * 
 */
public class SimilarityOnDisk implements Similarity {

	private static final long serialVersionUID = 9046114488457508772L;
	private String tmp;
	private Set<Edge> edges;

	/**
	 * �ގ��x�͖���`
	 */
	public static final float NOVALUE = -2.2F;
	
	private static final int DIFFTMP_SIZE = 200;

	/**
	 * ����������
	 */
	public SimilarityOnDisk(String tmp) {
		this.tmp = tmp + "\\diff";
		DirecttoryUtil.initDirectory(this.tmp);
		edges = new THashSet<Edge>();	
	}

	/**
	 * �t�@�C���Ԃ̗ގ��x��ݒ肷��
	 * 
	 * @param id1
	 *            fileId 1
	 * @param id2
	 *            fileId 2
	 * @param similarity
	 *            �ގ��x
	 */
	public void setSimilarity(int id1, int id2, float similarity) {
		setSimilarity(new Edge(id1, id2), similarity);
	}

	/**
	 * �t�@�C���Ԃ̗ގ��x��ݒ肷��
	 * 
	 * @param id1
	 *            fileId 1
	 * @param id2
	 *            fileId 2
	 * @param similarity
	 *            �ގ��x
	 */
	public void setSimilarity(Edge edge, float similarity) {
		DirecttoryUtil.initDirectory(tmp + '\\' + difftmpSmall(edge));
		synchronized (edges) {
			edges.add(edge);
		}
		try {
			BufferedWriter bw = new BufferedWriter(new FileWriter(diffFile(edge)));
			bw.append(Float.toString(similarity));
			bw.append('\n');
			bw.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	/**
	 * �t�@�C���Ԃ̗ގ��x�𓾂�
	 * 
	 * @param id1
	 *            fileId 1
	 * @param id2
	 *            fileId 2
	 * @return �ގ��x
	 */
	public float getSimilarity(int id1, int id2) {
		Edge edge = new Edge(id1, id2);
		return getSimilarity(edge);
	}

	/**
	 * �t�@�C���Ԃ̗ގ��x�𓾂�
	 * 
	 * @param id1
	 *            fileId 1
	 * @param id2
	 *            fileId 2
	 * @return �ގ��x
	 */
	public float getSimilarity(Edge edge) {
		if (edges.contains(edge)) {
			File tmp = diffFile(edge);
			if (tmp.exists()) {
				try {
					BufferedReader fin = new BufferedReader(new FileReader(tmp));
					String line = fin.readLine(); // sim
					fin.close();
					if (line != null) {
						return Float.parseFloat(line);
					}
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
		return NOVALUE;
	}

	/**
	 * �t�@�C�����O���[�v������
	 * 
	 * @param similarity
	 *            �ގ��x臒l
	 * @return �O���[�v�̃Z�b�g
	 */
	public THashSet<Group> getFileGroup(float similarity) {
		THashSet<Group> groups = new THashSet<Group>();
		System.out.print("grouping");
		for (Edge edge : edges) {
			float sim = getSimilarity(edge);
			if (sim >= similarity) {
				System.out.print('.');
				THashSet<Group> toBeDeleted = new THashSet<Group>();
				Group newGroup = new Group();
				for (Group group : groups) {
					if (group.contains(edge.fileId1()) || group.contains(edge.fileId2())) {
						toBeDeleted.add(group);
						newGroup.addAll(group);
					}
				}
				newGroup.addEdge(edge);
				groups.removeAll(toBeDeleted);
				groups.add(newGroup);
			}
		}
		System.out.println();
		return groups;
	}

	private File diffFile(Edge edge) {
		return new File(tmp + '\\' + difftmpSmall(edge) + '\\' + edge.fileId1() + '_' + edge.fileId2() + ".diff");
	}

	private int difftmpSmall(Edge edge) {
		return edge.hashCode() / DIFFTMP_SIZE;
	}

	/**
	 * diff��ݒ肷��
	 * 
	 * @param edge
	 *            ��
	 * @param diff
	 *            diff�̃e�L�X�g
	 */
	public void setDiffString(Edge edge, String diff) {
		try {
			BufferedWriter bw; 
			if (edge.fileId1() < 0) {
				// �܂Ƃ߂�diff
				bw = new BufferedWriter(new FileWriter(diffFile(edge)));
				bw.append('\n');
			} else {
				bw = new BufferedWriter(new FileWriter(diffFile(edge), true));
			}
			bw.append(Integer.toString(diff.replaceAll("\r\n", "\n").replaceAll("[^<>].*\\n", "").length()));
			bw.append('\n');
			bw.append(diff);
			bw.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	/**
	 * diff�̃e�L�X�g���擾����
	 * 
	 * @param edge
	 *            ��
	 * @return diff�̃e�L�X�g
	 */
	public String getDiffString(Edge edge) {
		File tmp = diffFile(edge);
		if (tmp.exists()) {
			StringBuilder result = new StringBuilder();
			String line;
			try {
				BufferedReader fin = new BufferedReader(new FileReader(tmp));
				fin.readLine(); // sim
				fin.readLine(); // size
				while (null != (line = fin.readLine())) {
					result.append(line);
					result.append('\n');
				}
				fin.close();
				return result.toString();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return "";
	}

	/**
	 * diff�̍s�����擾����
	 * 
	 * @param edge
	 *            ��
	 * @return diff�̃e�L�X�g
	 */
	public int getDiffSize(Edge edge) {
		File tmp = diffFile(edge);
		if (tmp.exists()) {
			try {
				BufferedReader fin = new BufferedReader(new FileReader(tmp));
				fin.readLine(); // sim
				String line = fin.readLine(); // size
				fin.close();
				if (line != null) {
					return Integer.parseInt(line);
				}
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return -1;
	}

	/**
	 * �w�肳�ꂽ������̍ŒZ�o�H�؂��\�z����B �����������������ꍇ�̃��[�g�I�����������B �s���x�[�X�ł���Ă�̂Ő��`�ɂ����Ȃ�Ȃ���������Ȃ��B
	 * 
	 * @param group
	 *            ���߂����O���[�v
	 * @param rootId
	 *            ���̃t�@�C��ID�B�O���[�v�Ɋ܂܂�Ă��Ȃ����null��Ԃ�
	 * @return �ŒZ�o�H�؁i���͂�group����ӂ����肵�����́j or null
	 */
	public Group getShortestPath(Group group, int rootId) {
		if (!group.files().contains(rootId)) {
			return null;
		}

		int maxSize = group.files().size();

		TIntObjectMap<Edge> dMap = new TIntObjectHashMap<Edge>((int) (maxSize * 1.25));
		// D[]
		TIntIntMap distance = new TIntIntHashMap((int) (maxSize * 1.25));

		// X = ��
		TIntSet x = new TIntHashSet((int) (maxSize * 1.25));
		x.add(rootId);
		// V - X
		TIntSet vx = new TIntHashSet(group.files());
		vx.remove(rootId);

		// u ~ somewhere
		for (TIntIterator it = vx.iterator(); it.hasNext();) {
			int v = it.next();
			Edge uv = new Edge(v, rootId);
			int dis = getDiffSize(uv);
			if (dis >= 0) {
				distance.put(v, dis);
			} else {
				distance.put(v, Integer.MAX_VALUE);
			}
			dMap.put(v, uv);
		}

		Group sh = new Group();

		while (vx.size() != 0) {
			int u = rootId;
			int minDistance = Integer.MAX_VALUE;

			// X ~ V �̕ӂɂ���
			for (TIntIterator it = vx.iterator(); it.hasNext();) {
				int id = it.next();
				int dis = distance.get(id);
				if (dis < minDistance) {
					u = id;
					minDistance = dis;
				}
			}

			// null ?
			// X += u
			sh.addEdge(dMap.get(u));
			x.add(u);

			// V - X
			vx.remove(u);

			// u ~ (V - X) �ւ̕ӂ�����΋��������X�V
			for (TIntIterator it = vx.iterator(); it.hasNext();) {
				int v = it.next();
				Edge uv = new Edge(u, v);
				int diffSize = getDiffSize(uv);
				if (diffSize >= 0.0 && distance.get(v) > distance.get(u) + diffSize) {
					distance.put(v, distance.get(u) + diffSize);
					dMap.put(v, uv);
				}
			}
		}
		return sh;
	}

	public int getDiffSize(Group group) {
		int size = 0;
		for (Edge edge : group.edges()) {
			size += getDiffSize(edge);
		}
		return size;
	}

	public void printAll() {
		File tmp = new File("sim.txt");
		try {
			BufferedWriter bw = new BufferedWriter(new FileWriter(tmp));
			for (Edge edge : edges) {
				bw.append(edge.toString());
				bw.append(" , " + getSimilarity(edge));
				bw.append('\n');
			}
			bw.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}
