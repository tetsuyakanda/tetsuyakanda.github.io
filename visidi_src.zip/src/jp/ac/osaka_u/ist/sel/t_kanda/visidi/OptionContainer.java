//Copyright (c) 2012 Tetsuya Kanda
//http://sel.ist.osaka-u.ac.jp/~t-kanda/
//
//Permission is hereby granted, free of charge, to any person obtaining
//a copy of this software and associated documentation files (the
//"Software"), to deal in the Software without restriction, including
//without limitation the rights to use, copy, modify, merge, publish,
//distribute, sublicense, and/or sell copies of the Software, and to
//permit persons to whom the Software is furnished to do so, subject to
//the following conditions:
//
//The above copyright notice and this permission notice shall be
//included in all copies or substantial portions of the Software.
//
//THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
//EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
//MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
//NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
//LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
//OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
//WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

package jp.ac.osaka_u.ist.sel.t_kanda.visidi;

import gnu.trove.map.TObjectCharMap;
import gnu.trove.map.hash.TObjectCharHashMap;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

import org.apache.commons.cli.BasicParser;
import org.apache.commons.cli.CommandLine;
import org.apache.commons.cli.CommandLineParser;
import org.apache.commons.cli.OptionBuilder;
import org.apache.commons.cli.Options;
import org.apache.commons.cli.ParseException;

public class OptionContainer {

	String diffCmd;
	String gvCmd;
	TObjectCharMap<String> types;
	boolean onepath = true;
	boolean onMemory;
	String tmp;

	/**
	 * ��������͂��A�i�[����N���X
	 * @param args
	 */
	public OptionContainer(String args[]) {

		// �����������܂�
		Options options = new Options();
		OptionBuilder.withLongOpt("diff");
		OptionBuilder.hasArg();
		OptionBuilder.withArgName("diff command");
		options.addOption(OptionBuilder.create());

		OptionBuilder.withLongOpt("one");
		OptionBuilder.withDescription("calc diff and similarity at the same time");
		options.addOption(OptionBuilder.create());
		
		OptionBuilder.withLongOpt("m");
		OptionBuilder.withDescription("save diff on memory");
		options.addOption(OptionBuilder.create());

		OptionBuilder.withLongOpt("graph");
		OptionBuilder.hasArg();
		OptionBuilder.withArgName("dot command");
		options.addOption(OptionBuilder.create());

		OptionBuilder.withLongOpt("type");
		OptionBuilder.isRequired();
		OptionBuilder.hasArg();
		OptionBuilder.withArgName("type");
		options.addOption(OptionBuilder.create());
		
		OptionBuilder.withLongOpt("tmp");
		OptionBuilder.isRequired();
		OptionBuilder.hasArg();
		OptionBuilder.withArgName("temp directory");
		options.addOption(OptionBuilder.create());

		CommandLineParser parser = new BasicParser();
		CommandLine cmd;
		try {
			cmd = parser.parse(options, args);
		} catch (ParseException e) {
			System.err.println("PARSE ARGS ERROR");
			return;
		}
		if (cmd.hasOption("one")) {
			diffCmd = null;
			onepath = true;
		} else if (cmd.hasOption("diff")) {
			diffCmd = cmd.getOptionValue("diff");
		} else {
			diffCmd = null;
		}

		if (cmd.hasOption("graph")) {
			gvCmd = cmd.getOptionValue("graph");
		} else {
			gvCmd = null;
		}

		if (cmd.hasOption("type")) {
			types = new TObjectCharHashMap<String>();
			readTypeConf(cmd.getOptionValue("type"));
		}
		
		if (cmd.hasOption("tmp")) {
			tmp = cmd.getOptionValue("tmp");
		}
		
		onMemory = cmd.hasOption('m');
	}

	private void readTypeConf(String path) {
		FileReader in;
		BufferedReader br;
		try {
			in = new FileReader(path);
			br = new BufferedReader(in);

			String line;
			while ((line = br.readLine()) != null) {
				String[] test = line.split(",");
				if (test.length > 1) {
					types.put(test[0], test[1].charAt(0));
				} else {
					types.put(test[0], 'D');
				}
			}

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public String diffCmd() {
		return diffCmd;
	}

	public String gvCmd() {
		return gvCmd;
	}
	
	public String tmp() {
		return tmp;
	}

	public TObjectCharMap<String> types() {
		return types;
	}
	
	public boolean onMemory(){
		return onMemory;
	}
	
	public boolean onepath(){
		return onepath;
	}

}
