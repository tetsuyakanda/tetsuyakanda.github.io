//Copyright (c) 2012 Tetsuya Kanda
//http://sel.ist.osaka-u.ac.jp/~t-kanda/
//
//Permission is hereby granted, free of charge, to any person obtaining
//a copy of this software and associated documentation files (the
//"Software"), to deal in the Software without restriction, including
//without limitation the rights to use, copy, modify, merge, publish,
//distribute, sublicense, and/or sell copies of the Software, and to
//permit persons to whom the Software is furnished to do so, subject to
//the following conditions:
//
//The above copyright notice and this permission notice shall be
//included in all copies or substantial portions of the Software.
//
//THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
//EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
//MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
//NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
//LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
//OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
//WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

package jp.ac.osaka_u.ist.sel.t_kanda.visidi.similarity;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;


import gnu.trove.iterator.TIntIterator;
import gnu.trove.map.TIntIntMap;
import gnu.trove.map.TIntObjectMap;
import gnu.trove.map.TMap;
import gnu.trove.map.TObjectIntMap;
import gnu.trove.map.hash.THashMap;
import gnu.trove.map.hash.TIntIntHashMap;
import gnu.trove.map.hash.TIntObjectHashMap;
import gnu.trove.map.hash.TObjectFloatHashMap;
import gnu.trove.map.hash.TObjectIntHashMap;
import gnu.trove.set.TIntSet;
import gnu.trove.set.hash.THashSet;
import gnu.trove.set.hash.TIntHashSet;

/**
 * �t�@�C���Ԃ̊֌W��ێ�����N���X�B�ގ��x�Adiff�̏o�́Adiff�̏o�͂̍s��
 * 
 * @author t-kanda
 * 
 */
public class SimilarityOnMemory implements Similarity{

	private static final long serialVersionUID = -3678590840666156337L;
	private TObjectFloatHashMap<Edge> similarityMap;
	private TMap<Edge, String> diffStringMap;
	private TObjectIntMap<Edge> diffLinesMap;

	/**
	 * �ގ��x�v�Z�����Ȃ��A�Ƃ�����
	 */
	public static final double DONTTOUCH = -1.1F;

	/**
	 * �ގ��x�͖���`
	 */
	public static final float NOVALUE = -2.2F;

	/**
	 * ����������
	 */
	public SimilarityOnMemory() {
		similarityMap = new TObjectFloatHashMap<Edge>();
		diffStringMap = new THashMap<Edge, String>();
		diffLinesMap = new TObjectIntHashMap<Edge>();
	}

	/**
	 * �t�@�C���Ԃ̗ގ��x��ݒ肷��
	 * 
	 * @param id1
	 *            fileId 1
	 * @param id2
	 *            fileId 2
	 * @param similarity
	 *            �ގ��x
	 */
	public void setSimilarity(int id1, int id2, float similarity) {
		setSimilarity(new Edge(id1, id2), similarity);
	}

	/**
	 * �t�@�C���Ԃ̗ގ��x��ݒ肷��
	 * 
	 * @param id1
	 *            fileId 1
	 * @param id2
	 *            fileId 2
	 * @param similarity
	 *            �ގ��x
	 */
	public synchronized void setSimilarity(Edge edge, float similarity) {
		similarityMap.put(edge, similarity);
	}

	/**
	 * �t�@�C���Ԃ̗ގ��x�𓾂�
	 * 
	 * @param id1
	 *            fileId 1
	 * @param id2
	 *            fileId 2
	 * @return �ގ��x
	 */
	public float getSimilarity(int id1, int id2) {
		Edge edge = new Edge(id1, id2);
		if (similarityMap.containsKey(edge)) {
			return similarityMap.get(edge);
		} else {
			// System.out.print("+");
			return NOVALUE;
		}
	}

	/**
	 * �t�@�C���Ԃ̗ގ��x�𓾂�
	 * 
	 * @param id1
	 *            fileId 1
	 * @param id2
	 *            fileId 2
	 * @return �ގ��x
	 */
	public float getSimilarity(Edge edge) {
		if (similarityMap.containsKey(edge)) {
			return similarityMap.get(edge);
		} else {
			// System.out.print("+");
			return NOVALUE;
		}
	}

	/**
	 * �t�@�C�����O���[�v������
	 * 
	 * @param similarity
	 *            �ގ��x臒l
	 * @return �O���[�v�̃Z�b�g
	 */
	public THashSet<Group> getFileGroup(float similarity) {
		THashSet<Group> groups = new THashSet<Group>();
		System.out.print("grouping");
		for (Edge edge : similarityMap.keySet()) {
			double sim = similarityMap.get(edge);
			if (sim >= similarity) {
				System.out.print(".");
				THashSet<Group> toBeDeleted = new THashSet<Group>();
				Group newGroup = new Group();
				for (Group group : groups) {
					if (group.contains(edge.fileId1()) || group.contains(edge.fileId2())) {
						toBeDeleted.add(group);
						newGroup.addAll(group);
					}
				}
				newGroup.addEdge(edge);
				groups.removeAll(toBeDeleted);
				groups.add(newGroup);
			}
		}
		System.out.println();
		return groups;
	}

	/**
	 * diff��ݒ肷��
	 * 
	 * @param edge
	 *            ��
	 * @param diff
	 *            diff�̃e�L�X�g
	 */
	public synchronized void setDiffString(Edge edge, String diff) {
		diffStringMap.put(edge, diff);
		diffLinesMap.put(edge, diff.replaceAll("\r\n", "\n").replaceAll("[^<>].*\\n", "").length());
	}

	/**
	 * diff�̃e�L�X�g���擾����
	 * 
	 * @param edge
	 *            ��
	 * @return diff�̃e�L�X�g
	 */
	public String getDiffString(Edge edge) {
		if (diffStringMap.containsKey(edge)) {
			return diffStringMap.get(edge);
		} else {
			return "";
		}
	}

	/**
	 * diff�̍s�����擾����
	 * 
	 * @param edge
	 *            ��
	 * @return diff�̃e�L�X�g
	 */
	public int getDiffSize(Edge edge) {
		if (diffLinesMap.containsKey(edge)) {
			return diffLinesMap.get(edge);
		} else {
			return -1;
		}
	}

	/**
	 * �w�肳�ꂽ������̍ŒZ�o�H�؂��\�z����B �����������������ꍇ�̃��[�g�I�����������B �s���x�[�X�ł���Ă�̂Ő��`�ɂ����Ȃ�Ȃ���������Ȃ��B
	 * 
	 * @param group
	 *            ���߂����O���[�v
	 * @param rootId
	 *            ���̃t�@�C��ID�B�O���[�v�Ɋ܂܂�Ă��Ȃ����null��Ԃ�
	 * @return �ŒZ�o�H�؁i���͂�group����ӂ����肵�����́j or null
	 */
	public Group getShortestPath(Group group, int rootId) {
		if (!group.files().contains(rootId)) {
			return null;
		}

		int maxSize = group.files().size();

		TIntObjectMap<Edge> dMap = new TIntObjectHashMap<Edge>((int) (maxSize * 1.25));
		// D[]
		TIntIntMap distance = new TIntIntHashMap((int) (maxSize * 1.25));

		// X = ��
		TIntSet x = new TIntHashSet((int) (maxSize * 1.25));
		x.add(rootId);
		// V - X
		TIntSet vx = new TIntHashSet(group.files());
		vx.remove(rootId);

		// u ~ somewhere
		for (TIntIterator it = vx.iterator(); it.hasNext();) {
			int v = it.next();
			Edge uv = new Edge(v, rootId);
			int dis = getDiffSize(uv);
			if (dis >= 0) {
				distance.put(v, dis);
			} else {
				distance.put(v, Integer.MAX_VALUE);
			}
			dMap.put(v, uv);
		}

		Group sh = new Group();

		while (vx.size() != 0) {
			int u = rootId;
			int minDistance = Integer.MAX_VALUE;

			// X ~ V �̕ӂɂ���
			for (TIntIterator it = vx.iterator(); it.hasNext();) {
				int id = it.next();
				int dis = distance.get(id);
				if (dis < minDistance) {
					u = id;
					minDistance = dis;
				}
			}

			// null ?
			// X += u
			sh.addEdge(dMap.get(u));
			x.add(u);

			// V - X
			vx.remove(u);

			// u ~ (V - X) �ւ̕ӂ�����΋��������X�V
			for (TIntIterator it = vx.iterator(); it.hasNext();) {
				int v = it.next();
				Edge uv = new Edge(u, v);
				int diffSize = getDiffSize(uv);
				if (diffSize >= 0.0 && distance.get(v) > distance.get(u) + diffSize) {
					distance.put(v, distance.get(u) + diffSize);
					dMap.put(v, uv);
				}
			}
		}
		return sh;
	}

	public int getDiffSize(Group group) {
		int size = 0;
		for (Edge edge : group.edges()) {
			size += getDiffSize(edge);
		}
		return size;
	}
	
	public void printAll(){
		File tmp = new File("sim.txt");
		try {
			FileOutputStream fos = new FileOutputStream(tmp);
			OutputStreamWriter os = new OutputStreamWriter(fos);
			for(Edge edge : similarityMap.keySet()){
				os.append(edge.toString());
				os.append(" , " + similarityMap.get(edge));
				os.append('\n');
			}
			os.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}
