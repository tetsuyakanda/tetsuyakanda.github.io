//Copyright (c) 2012 Tetsuya Kanda
//http://sel.ist.osaka-u.ac.jp/~t-kanda/
//
//Permission is hereby granted, free of charge, to any person obtaining
//a copy of this software and associated documentation files (the
//"Software"), to deal in the Software without restriction, including
//without limitation the rights to use, copy, modify, merge, publish,
//distribute, sublicense, and/or sell copies of the Software, and to
//permit persons to whom the Software is furnished to do so, subject to
//the following conditions:
//
//The above copyright notice and this permission notice shall be
//included in all copies or substantial portions of the Software.
//
//THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
//EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
//MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
//NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
//LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
//OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
//WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

package jp.ac.osaka_u.ist.sel.t_kanda.visidi.similarity.calc;

import java.io.File;

import jp.ac.osaka_u.ist.sel.t_kanda.visidi.OptionContainer;
import jp.ac.osaka_u.ist.sel.t_kanda.visidi.ParaRun;
import jp.ac.osaka_u.ist.sel.t_kanda.visidi.diff.DiffFactory;
import jp.ac.osaka_u.ist.sel.t_kanda.visidi.diff.DiffInterface;
import jp.ac.osaka_u.ist.sel.t_kanda.visidi.projects.FileInfo;
import jp.ac.osaka_u.ist.sel.t_kanda.visidi.similarity.Edge;
import jp.ac.osaka_u.ist.sel.t_kanda.visidi.similarity.Group;
import jp.ac.osaka_u.ist.sel.t_kanda.visidi.similarity.Similarity;



import gnu.trove.map.TIntObjectMap;


public class DiffCalc {
	private Similarity diffmap;
	private TIntObjectMap<FileInfo> files;
	private DiffInterface diff;

	/**
	 * �����v�Z���s���N���X
	 * @param diffmap
	 * @param files
	 * @param options
	 */
	public DiffCalc(Similarity diffmap, TIntObjectMap<FileInfo> files,OptionContainer options) {
		this.diffmap = diffmap;
		this.files = files;
		diff = DiffFactory.create(options.diffCmd());
	}

	public void calcDiff(Group group) {

		ParaRun<Calc> pararun = new ParaRun<Calc>();
		for (Edge edge : group.edges()) {
			if (diffmap.getDiffSize(edge) < 0) {
				pararun.add(new Calc(edge));
			}
		}
		pararun.run();
	}

	private class Calc implements Runnable {
		Edge edge;

		public Calc(Edge edge) {
			this.edge = edge;
		}

		public void run() {
			File file1 = files.get(edge.fileId1()).preDiff;
			File file2 = files.get(edge.fileId2()).preDiff;
			String diffresult = diff.diff(file1, file2);
			synchronized (diffmap) {
				diffmap.setDiffString(edge, diffresult);
			}
		}

	}
}
