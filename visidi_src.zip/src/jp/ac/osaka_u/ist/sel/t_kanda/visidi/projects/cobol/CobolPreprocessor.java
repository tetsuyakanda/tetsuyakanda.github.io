//Copyright (c) 2012 Tetsuya Kanda
//http://sel.ist.osaka-u.ac.jp/~t-kanda/
//
//Permission is hereby granted, free of charge, to any person obtaining
//a copy of this software and associated documentation files (the
//"Software"), to deal in the Software without restriction, including
//without limitation the rights to use, copy, modify, merge, publish,
//distribute, sublicense, and/or sell copies of the Software, and to
//permit persons to whom the Software is furnished to do so, subject to
//the following conditions:
//
//The above copyright notice and this permission notice shall be
//included in all copies or substantial portions of the Software.
//
//THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
//EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
//MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
//NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
//LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
//OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
//WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

package jp.ac.osaka_u.ist.sel.t_kanda.visidi.projects.cobol;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.OutputStreamWriter;

import jp.ac.osaka_u.ist.sel.t_kanda.visidi.projects.FileInfo;
import jp.ac.osaka_u.ist.sel.t_kanda.visidi.projects.Preprocessor;




/**
 * 
 * �J�����Œ��COBOL�p�B
 * �ގ��x�v�Z�O�̓R�����g�ƈ�A�ԍ��̈���폜�B
 * �����v�Z�O�̓R�����g�ƈ�A�ԍ��̈���폜�B
 * @author t-kanda
 *
 */
public class CobolPreprocessor extends Preprocessor {

	public CobolPreprocessor(String tmp) {
		super(tmp);
	}

	@Override
	public void preprocessForCalcSimilarity(FileInfo source) {
		try {
			File path = new File("tmp/" + source.fileId() + "_t.tmp");
			uncomment(source.file(), new FileOutputStream(path));
			source.preSim = path;
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
	
	private static void uncomment(File source, FileOutputStream fos){
		
		BufferedReader fin;
		try {
			String line;
			StringBuilder buffer = new StringBuilder();
			fin = new BufferedReader(new FileReader(source));
			while (null != (line = fin.readLine())) {
				if(line.length() > 6 && line.charAt(6) != '*' && line.charAt(6) != '/'){
					buffer.append(line.substring(7));
					buffer.append('\n');
				}
			}
			OutputStreamWriter os = new OutputStreamWriter(fos);
			os.write(buffer.toString());
			os.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	@Override
	public void preprocessForDiff(FileInfo source) {
		source.preDiff = source.preSim;
	}

}
