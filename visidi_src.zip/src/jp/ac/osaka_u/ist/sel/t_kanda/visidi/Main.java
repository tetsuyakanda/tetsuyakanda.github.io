//Copyright (c) 2012 Tetsuya Kanda
//http://sel.ist.osaka-u.ac.jp/~t-kanda/
//
//Permission is hereby granted, free of charge, to any person obtaining
//a copy of this software and associated documentation files (the
//"Software"), to deal in the Software without restriction, including
//without limitation the rights to use, copy, modify, merge, publish,
//distribute, sublicense, and/or sell copies of the Software, and to
//permit persons to whom the Software is furnished to do so, subject to
//the following conditions:
//
//The above copyright notice and this permission notice shall be
//included in all copies or substantial portions of the Software.
//
//THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
//EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
//MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
//NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
//LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
//OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
//WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

package jp.ac.osaka_u.ist.sel.t_kanda.visidi;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Arrays;
import java.util.Collection;

import jp.ac.osaka_u.ist.sel.t_kanda.visidi.projects.FileInfo;
import jp.ac.osaka_u.ist.sel.t_kanda.visidi.projects.ProjectManager;

/**
 * CUI�̃��C��
 * 
 * @author t-kanda
 * 
 */
public class Main {

	static ProjectManager pm;

	/**
	 * CUI�̃��C���B��������͂��߂܂�
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		OptionContainer oc = new OptionContainer(args);
		initDirectories(oc.tmp);
		pm = new ProjectManager(oc);

		// ����
		BufferedReader stdReader = new BufferedReader(new InputStreamReader(System.in));
		String line;
		try {
			while (true) {
				System.out.print("INPUT:");
				line = stdReader.readLine();

				long l1 = System.currentTimeMillis();
				String[] state = line.split(" ");
				if (state[0].equals("exit")) {
					return;
				} else if (state[0].equals("read")) {
					com_read_test(Arrays.copyOfRange(state, 1, state.length));
				} else if (state[0].equals("group")) {
					com_group(Arrays.copyOfRange(state, 1, state.length));
				} else if (state[0].equals("show")) {
					if (state.length < 2) {
						com_show_groups();
					} else {
						com_show_group(Arrays.copyOfRange(state, 1, state.length));
					}
				} else if (state[0].equals("sp")) {
					if (state.length < 2) {
						com_sp();
					} else {
						com_sp(Arrays.copyOfRange(state, 1, state.length));
					}
				} else if (state[0].equals("spd")) {
					com_sp2(Arrays.copyOfRange(state, 1, state.length));
				} else if (state[0].equals("sh")) {
					com_short(Arrays.copyOfRange(state, 1, state.length));
				} else if (state[0].equals("p")) {
					pm.printSim();
				} else if (state[0].equals("pGroup")) {
					pm.printGroup();
				} else if (state[0].equals("pReduce")) {
					pm.printDiffReduce();
				} else if (state[0].equals("d")) {
					com_d(Arrays.copyOfRange(state, 1, state.length));
				} else if (state[0].equals("save")) {
					com_write(Arrays.copyOfRange(state, 1, state.length));
				} else if (state[0].equals("load")) {
					com_load(Arrays.copyOfRange(state, 1, state.length));
				} else if (state[0].equals("gsave")) {
					com_gwrite(Arrays.copyOfRange(state, 1, state.length));
				} else if (state[0].equals("gload")) {
					com_gload(Arrays.copyOfRange(state, 1, state.length));
				} else if (state[0].equals("ssave")) {
					com_swrite(Arrays.copyOfRange(state, 1, state.length));
				} else if (state[0].equals("sload")) {
					com_sload(Arrays.copyOfRange(state, 1, state.length));
				}
				long l2 = System.currentTimeMillis();
				System.out.println((l2 - l1) + "m sec");
			}
		} catch (IOException e) {
			e.printStackTrace();
		} catch (ArrayIndexOutOfBoundsException e) {

			e.printStackTrace();
		}
	}

	private static void com_sload(String[] argv) {
		if (argv.length >= 2) {
			pm.readSpanningTree(argv[0], Float.parseFloat(argv[1]));
		}
	}

	private static void com_swrite(String[] argv) {
		if (argv.length >= 2) {
			pm.writeSpanningTree(argv[0], Float.parseFloat(argv[1]));
		}
	}

	private static void com_gload(String[] argv) {
		if (argv.length >= 2) {
			pm.readGroup(argv[0], Float.parseFloat(argv[1]));
		}
	}

	private static void com_gwrite(String[] argv) {
		if (argv.length >= 2) {
			pm.writeGroup(argv[0], Float.parseFloat(argv[1]));
		}
	}

	private static void com_write(String[] argv) {
		if (argv.length < 1) {
			pm.writeout("");
		} else {
			pm.writeout(argv[0]);
		}
	}

	private static void com_load(String[] argv) {
		if (argv.length < 1) {
			pm.readin("");
		} else {
			pm.readin(argv[0]);
		}
	}

	private static void initDirectories(String tmp) {
		DirecttoryUtil.initDirectory(tmp);
		DirecttoryUtil.initDirectory("dot");
		DirecttoryUtil.initDirectory("graph");
	}

	public static void addProject(String path) {
		Collection<FileInfo> files = pm.addProject(path);
		System.out.print("calcurating similarity");
		pm.calcSim(files);
		System.out.println();
	}

	public static void com_read_test(String[] argv) {
		addProject(argv[0]);
	}

	public static void com_group(String[] argv) {
		if (argv.length < 1) {
			System.out.println(pm.group(0.3F));
		} else {
			System.out.println(pm.group(Float.parseFloat(argv[0])));
		}
	}

	public static void com_show_groups() {
		System.out.println(pm.groupSize());
	}

	public static void com_show_group(String[] argv) {
		System.out.println(pm.showFilesInGroup(Integer.parseInt(argv[0])));
	}

	public static void com_sp2(String[] argv) {
		com_sp();
		pm.getDirectorySpanningTree(Integer.parseInt(argv[0]));
	}

	public static void com_sp(String[] argv) {
		pm.calcDiff(Integer.parseInt(argv[0]));
		pm.getSpanningTree(Integer.parseInt(argv[0]));
	}

	public static void com_sp() {
		for (int i = 0; i < pm.groupSize(); i++) {
			pm.calcDiff(i);
			pm.getSpanningTree(i);
		}
	}

	public static void com_short(String[] argv) {
		if (argv.length >= 2) {
			pm.calcDiff(Integer.parseInt(argv[0]));
			pm.getShortestPath(Integer.parseInt(argv[0]), Integer.parseInt(argv[1]));
		}
	}

	public static void com_d(String[] argv) {
		if (argv.length >= 2) {
			pm.printDiff(Integer.parseInt(argv[0]), Integer.parseInt(argv[1]));
		}
	}
}
