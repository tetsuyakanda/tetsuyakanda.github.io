//Copyright (c) 2012 Tetsuya Kanda
//http://sel.ist.osaka-u.ac.jp/~t-kanda/
//
//Permission is hereby granted, free of charge, to any person obtaining
//a copy of this software and associated documentation files (the
//"Software"), to deal in the Software without restriction, including
//without limitation the rights to use, copy, modify, merge, publish,
//distribute, sublicense, and/or sell copies of the Software, and to
//permit persons to whom the Software is furnished to do so, subject to
//the following conditions:
//
//The above copyright notice and this permission notice shall be
//included in all copies or substantial portions of the Software.
//
//THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
//EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
//MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
//NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
//LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
//OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
//WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

package jp.ac.osaka_u.ist.sel.t_kanda.visidi.projects;

import gnu.trove.set.TIntSet;
import gnu.trove.set.hash.THashSet;
import gnu.trove.set.hash.TIntHashSet;

import java.io.File;
import java.io.Serializable;
import java.util.Set;

/**
 * �f�B���N�g���̏����i�[����N���X�B�T�u�f�B���N�g����DirectoryInfo�A���̃t�@�C����fileId�ŕێ��B
 * 
 * @author t-kanda
 * 
 */
public class DirectoryInfo implements Serializable{
	private static final long serialVersionUID = -814903566551162714L;
	private int fileId, projectId;
	private File source;
	private int parentDirFileId;
	private Set<DirectoryInfo> directories;
	private TIntSet files;

	public DirectoryInfo(File source, int fileId, int projectId, DirectoryInfo parent) {
		this.fileId = fileId;
		this.projectId = projectId;
		this.source = source;
		directories = new THashSet<DirectoryInfo>();
		files = new TIntHashSet();
		if (parent != null) {
			this.parentDirFileId = parent.fileId();
		}
	}

	public int getParentDirectory() {
		return parentDirFileId;
	}

	public boolean addFile(int fid) {
		return files.add(fid);
	}

	public TIntSet files() {
		return files;
	}

	public TIntSet allFiles() {
		TIntSet all = new TIntHashSet(files);
		for(DirectoryInfo child : directories){
			all.addAll(child.allFiles());
		}
		return all;
	}
	
	public int numberOfFiles() {
		return files.size();
	}

	public boolean addDirectory(DirectoryInfo child) {
		return directories.add(child);
	}

	public Set<DirectoryInfo> subdirectories() {
		return directories;
	}

	public int fileId() {
		return fileId;
	}

	public int projectId() {
		return projectId;
	}

	public String getName() {
		return source.getName();
	}
	
	public String getPath(){
		return source.getAbsolutePath();
	}
}