//Copyright (c) 2012 Tetsuya Kanda
//http://sel.ist.osaka-u.ac.jp/~t-kanda/
//
//Permission is hereby granted, free of charge, to any person obtaining
//a copy of this software and associated documentation files (the
//"Software"), to deal in the Software without restriction, including
//without limitation the rights to use, copy, modify, merge, publish,
//distribute, sublicense, and/or sell copies of the Software, and to
//permit persons to whom the Software is furnished to do so, subject to
//the following conditions:
//
//The above copyright notice and this permission notice shall be
//included in all copies or substantial portions of the Software.
//
//THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
//EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
//MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
//NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
//LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
//OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
//WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

package jp.ac.osaka_u.ist.sel.t_kanda.visidi.similarity;

import gnu.trove.set.TIntSet;
import gnu.trove.set.hash.THashSet;
import gnu.trove.set.hash.TIntHashSet;

/**
 * �t�@�C���ƕӂ̏W���B
 * @author t-kanda
 *
 */
public class Group {
	private TIntSet files;
	private THashSet<Edge> edges;
	
	public Group(){
		files = new TIntHashSet();
		edges = new THashSet<Edge>();
	}
	
	/**
	 * �ӂ�ǉ�
	 * @param edge ��
	 */
	public void addEdge(Edge edge){
		edges.add(edge);
		files.add(edge.fileId1());
		files.add(edge.fileId2());
	}
	
	public void addFile(int fileId){
		files.add(fileId);
	}
	
	public void removeFiles(TIntSet fileIds){
		files.removeAll(fileIds);
	}
	
	/**
	 * �O���[�v�Ƀt�@�C�����܂܂�Ă��邩�ǂ�����Ԃ��܂�
	 * @param fileId �t�@�C��ID
	 * @return
	 */
	public boolean contains(int fileId){
		return files.contains(fileId);
	}

	/**
	 * �O���[�v�܂邲�ƒǉ�
	 * @param group
	 */
	public void addAll(Group group) {
		this.edges.addAll(group.edges);
		this.files.addAll(group.files);
	}
	
	/**
	 * ���̃O���[�v�Ɋ܂܂��t�@�C���̈ꗗ��Ԃ��܂�
	 * @return �t�@�C��ID��Set
	 */
	public TIntSet files(){
		return files;
	}
	
	/**
	 * ���̃O���[�v�Ɋ܂܂��ӂ̈ꗗ��Ԃ��܂�
	 * @return �ӂ�Set
	 */
	public THashSet<Edge> edges(){
		return edges;
	}
}
